This directory is for Ruby DSL and JSON files for environments. For more information see the Chef wiki page:

https://docs.chef.io/environments.html
