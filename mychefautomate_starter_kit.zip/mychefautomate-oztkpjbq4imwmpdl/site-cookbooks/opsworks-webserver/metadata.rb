name "opsworks-webserver"
maintainer "AWS OpsWorks Demos"
maintainer_email "opsworks-feedback@amazon.com"

description "Installs/Configures a webserver"
long_description "Installs/Configures a webserver"
version "0.6.1"

depends "nginx", "~> 9.0.0"
